<?php

namespace Modules\Vehicle\Http\Controllers;

use App\Models\Vehicle;
use App\Models\Notification;
use App\Models\Option;
use App\Models\User;
use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Gate;
use Yajra\DataTables\DataTables;

class VehicleController extends Controller
{
    public function all()
    {
        return DataTables::of( Vehicle::all()->whereNotIn('deleted',true))->addIndexColumn()->make(true);
    }
    public function index()
    {
        if (Gate::allows('read vehicle')) {
            $version = Option::find('version_app')->value;
            $user=User::find(Auth::user()->user_id);
            $notifications= Notification::whereIn((new Notification())->getTable().'.type',['web'])
                ->where((new Notification())->getTable().'.status','=',null)
                ->where((new Notification())->getTable().'.send_to','=',Auth::user()->user_id)
                ->get();
            return view('vehicle::index',[
                'user'=>$user,
                'notifications'=>$notifications,
                'version'=>$version,
            ]);
        } else {
            abort(403,'TIDAK PUNYA AKSES');
        }
    }

    public function create()
    {
        if (Gate::allows('read vehicle')) {
            return view('vehicle::create');
        } else {
            abort(403,'TIDAK PUNYA AKSES');
        }
    }

    public function store(Request $request)
    {
        if (Gate::allows('create vehicle')) {
            DB::beginTransaction();
            try {
                Vehicle::create([
                    'vehicle_id'=> $request->dictionary_id,
                    'name'=> $request->dictionary_name,
                    'key'=> $request->key,
                    'create_by'=>Auth::user()->user_name,
                ]);
                DB::commit();
                return 'data berhasil disimpan';
            } catch (\Exception $e) {
                DB::rollback();
                throw $e;
            }
        } else {
            abort(403,'TIDAK PUNYA AKSES');
        }
    }

    public function show($id)
    {
        return view('vehicle::show');
    }

    public function edit($id)
    {
        if (Gate::allows('update vehicle')) {
            $vehicle = Vehicle::find($id);
            return view('vehicle::edit',[
                'vehicle'=>$vehicle
            ]);
        } else {
            abort(403,'TIDAK PUNYA AKSES');
        }
    }

    public function update(Request $request,Vehicle $vehicle)
    {
        try {
            $vehicle->update([
                'name'=>$request->dictionary_name,
                'update_by'=>Auth::user()->user_name,
            ]);
            DB::commit();
            return 'data berhasil disimpan';
        } catch (\Exception $e) {
            DB::rollback();
            throw $e;
        }
    }

    public function destroy(Request $request,Vehicle $vehicle)
    {
        try {
            $vehicle->update([
                'deleted'=>true,
                'delete_date'=>now(),
                'delete_by'=>Auth::user()->user_name,
                'delete_reason'=>$request->reason
            ]);
            DB::commit();
            return 'data berhasil disimpan';
        } catch (\Exception $e) {
            DB::rollback();
            throw $e;
        }
    }
}
