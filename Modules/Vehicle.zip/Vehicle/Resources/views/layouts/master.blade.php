@extends('template.layout.main')
@section('content')
    @yield('container')
@endsection
@include('template.partials.modal')
