<?php

return [
    'name' => 'Vehicle'
];
